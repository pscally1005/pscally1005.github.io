# WellnessWally
Wellness Wally is a health and fitness buddy that will allow you to rate your daily nutrition from 1 to 5, calculate your BMI, and calculate running splits and paces

- pscally1005